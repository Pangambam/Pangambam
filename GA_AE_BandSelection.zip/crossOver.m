%%
%CROSSOVER
%Child will take parent1 chromosome upto Position=position
%remaining from parent 2
%2Pts Crossover
function nextGen = crossOver(Parents)
if(mod(size(Parents,1),2)~=0)
    RMIDX = [1:size(Parents,1)] ~= randi(size(Parents,1));
    Parents = Parents(RMIDX,:);
end
MFPos = randperm(size(Parents,1));
nextGen = ones(size(Parents));
for i=1:2:size(MFPos,2)
    currParents = [Parents(MFPos(i),:);Parents(MFPos(i+1),:)];
    pos = randi(size(currParents,2),1,2);
    pos1 = min(pos);
    pos2 = max(pos);
    Male = currParents(1,:);
    FeMale = currParents(2,:);
    child1 = FeMale;
    child2 = Male;
    child1(1,1:pos1) = Male(1:pos1);
    child2(1,1:pos1) = FeMale(1:pos1);
    child1(1,pos2+1:size(Male,2)) = Male(pos2+1:size(Male,2));
    child2(1,pos2+1:size(Male,2)) = FeMale(pos2+1:size(Male,2));
    nextGen(i,:) = child1;
    nextGen(i+1,:) = child2;
end
end