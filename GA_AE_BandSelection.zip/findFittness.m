%%
%FIND FITNESS
function fitVal = findFittness(oriData, maskedData, AECell)
fitVal = zeros(1,size(maskedData,2));
for Count = 1:size(maskedData,2)
    currData = maskedData{Count};
    Reconstruction = getRepresentation(currData, AECell);
    PCCoeff = corrcoef(oriData,Reconstruction);
    fitVal(Count) = PCCoeff(2);
end
end