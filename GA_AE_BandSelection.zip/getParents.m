%%
%Find Parent pairs through RW Selection
function Parents = getParentsgetParents(nonElites, fitNonElites)
if(size(nonElites,1)>1)
    parentID = ones(size(nonElites,1),1);
    for i = 1:size(nonElites,1)
        random_num = sum(fitNonElites)*rand();
        part_sum = 0;
        for count = 1:size(nonElites,1)
            part_sum = part_sum + fitNonElites(count);
            if(random_num < part_sum)
                parentID(i,1) = count;
                break;
            end
        end
    end
    Parents = nonElites(parentID,:);
else
    Parents = [nonElites;randi([0,1],1,size(nonElites,2))];
end
end
%%