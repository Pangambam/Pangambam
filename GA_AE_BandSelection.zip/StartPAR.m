%START PARPOOL IF NOT ALREADY STARTED
function StartPAR()
if (isempty(gcp('nocreate'))==1)
    parpool;
end
end