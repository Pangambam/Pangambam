%%
%MASKING THR INPUT
function MASKED = applyMask(DATA, MASK)
MASKED = cell(1,size(MASK,1));
for i=1:size(MASK,1)
    currMask = MASK(i,:);
    MASKED{1,i} = currMask.*DATA;
end
end