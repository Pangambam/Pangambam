%%
%INITIAL POPULATION
function iniPOP = initPopulation(Dim, popSize)
iniPOP = logical(sprand(popSize, Dim, 0.7*rand()));
end