%%
clear;
%%
load('D:\DATASETS\HSI\ResizedFULL\INDIAN PINES\DATA.mat');
load('D:\DATASETS\HSI\ResizedFULL\INDIAN PINES\GT.mat');
GT = categorical(GT);
Class = unique(GT);
%%
%TotNumBand = 5;
numClusters = 5; %KEEP IT FIXED
CCCount = 1;
Model = cell(9,5);
CVModel = cell(9,5);
GenError = cell(9,5);
NumSelectBand = cell(9,5);
%%
for TotNumBand = 45:5:46
    for rptIt = 1:3
        fprintf('RPT : %d\n',rptIt);
        [IDX, Centers] = kmeans(DATA', numClusters);
        %Clusterwise data
        ClusterWise = cell(numClusters,1);
        for i = 1:numClusters
            ClusterWise(i) = {DATA(:,IDX==i)};
        end
        fprintf('CLUSTERED INTO %d CLUSTERS\n',numClusters);
        %%
        %TRAINING THE AUTOENCODERS IN EACH SEGMENTS/CLUSTERS IN PARALLEL
        fprintf('AutoEncoder Training Started\n');
        ClusterAECells = cell(1,numClusters);
        StartPAR();
        parfor clusterCount = 1:numClusters
            ClusterAECells{clusterCount}=TrainDSAE(ClusterWise{clusterCount});
            fprintf("Cluster no %d AE Training done!!!\n", clusterCount);
        end
        fprintf('AutoEncoder Training Finished\n');
        %AE j of Cluster i is ClusterAECells{i}{j}
        %%
        FinalMask = cell(1,numClusters);
        %%
        fprintf('GA to Find MASK to be started\n');
        StartPAR();
        parfor clusterCount = 1:numClusters
            currCluster = ClusterWise{clusterCount};
            DIM = size(currCluster,2);
            if (DIM == 1)
                FinalMask{clusterCount} = 1;
                continue;
            end
            popSize = 10; %POPULATION SIZE
            maxGAiterations = 15; %MAX GA ITERATIONS
            %%
            MASK = initPopulation(DIM, popSize); %Initialize Random Mask
            %%
            for GAiteration =1:maxGAiterations+1
                MASKED = applyMask(currCluster, MASK); %MASKing the input
                fitness = findFittness(currCluster, MASKED, ClusterAECells{clusterCount}); %Find Fitness
                if (GAiteration > maxGAiterations)
                    [~,highFitIDX] = sort(fitness, 'desc');
                    highFitIDX = highFitIDX(1);
                    FinalMask{clusterCount} = full(MASK(highFitIDX,:));
                    fprintf('Cluster =  %d Done with Fitness = %f \n',clusterCount, fitness(highFitIDX));
                    break;
                end
                normFitness = normalize(fitness, 'range');
                
                ELITEs = MASK(normFitness>0.75,:); %RETAIN ELITES
                
                nonELITEs = MASK(normFitness<=0.75,:);
                fitNonELITEs = fitness(normFitness<=0.75); %Fitness value of non Elites
                
                Parents = getParents(nonELITEs, fitNonELITEs); %Find Prarents
                nextGen = crossOver(Parents); %CROSSOVER
                nextGen = mutate(nextGen); %MUTATION OF EACH CHROMOSOME WITH PROB 3%
                MASK = [ELITEs;nextGen]; %NEW MASK =[ELITEs;Gen]
                %fprintf('Cluster no. : %d, GA iteration: %d Done! Best Fitness = %f\n',clusterCount, GAiteration, fitness(1));
            end
        end
        %%
        %%END OF GA
        %%BAND SELECTION FROM EACH CLUSTERS
        %Number of Bands per cluster
        totBandSelByGA = sum(cell2mat(FinalMask));
        numBandPerCluster = ones(1,numClusters);
        for clusterCount = 1:numClusters
            currNumBand = round(TotNumBand*full(sum(FinalMask{clusterCount}))/totBandSelByGA);
            if currNumBand>1
                numBandPerCluster(clusterCount) = currNumBand;
            end
        end
        %%
        clusterWiseSelBand = cell(1,numClusters);
        for clusterCount = 1:numClusters
            FullFeature = FinalMask{clusterCount}.*ClusterWise{clusterCount};
            selBandIDX = FullFeature ~= zeros(size(DATA,1),1);
            SelBand = reshape(FullFeature(selBandIDX),[size(DATA,1),sum(FinalMask{clusterCount})]);
            if(size(SelBand,2)==0)
                SelBand = ClusterWise{clusterCount}(:,randi(size(ClusterWise{clusterCount},2)));
            end
            selIDX = randi(size(SelBand,2),1,numBandPerCluster(clusterCount));
            clusterWiseSelBand{clusterCount} = SelBand(:,selIDX);
            clear FullFeature; clear selBandIDX; clear SelBand; clear selIDX; clear selBandIDX;
        end
        %Combining selected bands from all the clusters
        SelectedBand = full(cell2mat(clusterWiseSelBand));
        NumSelectBand{CCCount,rptIt} = size(SelectedBand,2);
        fprintf('BAND SELECTION DONE!!! No. of Selected Bands: %d\n',size(SelectedBand,2));
        %%
        %CLASSIFICATION PROCESS STARTS HERE
        normDATA = zscore(SelectedBand);
        %t = templateSVM('Standardize',true,'KernelFunction','gaussian');
        t = templateSVM('Standardize',true,'KernelFunction','rbf');
        %tMdl = fitcecoc(normDATA,GT,'Learners',t,'Options',options);
        %Mdl = fitcecoc(normDATA,GT);
        %tCVMdl = crossval(tMdl);
        %tgenError = kfoldLoss(tCVMdl);
        StartPAR();
        options = statset('UseParallel',true);
        %Mdl = fitcecoc(normDATA,GT,'Options',options);
        Mdl = fitcecoc(normDATA,GT,'Learners',t,'Options',options);
        CVMdl = crossval(Mdl,'Options',options);
        genError = kfoldLoss(CVMdl);
        genError
        Model{CCCount,rptIt} = Mdl;
        CVModel{CCCount,rptIt} = CVMdl;
        GenError{CCCount,rptIt} = genError;
    end
    CCCount = CCCount+1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%