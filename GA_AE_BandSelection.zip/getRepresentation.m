%%
%Reconstruction of the masked input
function ReConstruction = getRepresentation(maskedINPUT, SAEcell)
ReConstruction = maskedINPUT';
for aeCount = 1:size(SAEcell,2)
    ReConstruction = encode(SAEcell{aeCount},ReConstruction);
end
for aeCount = aeCount:-1:1
    ReConstruction = decode(SAEcell{aeCount},ReConstruction);
end
ReConstruction=ReConstruction';
end
