%Train DynamicSAE
function SAE = TrainDSAE(DATA)
DIM = size(DATA,2);
if (DIM == 1)
    sizeLayerWise = 1;
else
    SIZEofLastHidden = round(log2(DIM));
    %SIZEofLastHidden = sqrt(DIM);
    sizeLayerWise = [];
    while(DIM>SIZEofLastHidden)
        DIM = sqrt(DIM*2)-1;
        %DIM = (2/3)*DIM;
        sizeLayerWise = [sizeLayerWise,round(DIM)];
    end
end
AEfeat = {DATA'};
SAE = cell(1,size(sizeLayerWise,2));
for aeCount = 1:size(sizeLayerWise,2)
    currFeat = AEfeat{aeCount};
    AE = trainAutoencoder(currFeat,sizeLayerWise(aeCount),...
        'MaxEpochs',1000,...
        'EncoderTransferFunction','logsig',...
        'DecoderTransferFunction','purelin',...
        'L2WeightRegularization',0.004, ...
        'SparsityRegularization',4, ...
        'SparsityProportion',0.15);
    SAE{aeCount} = AE;
    AEfeat{aeCount+1} = encode(SAE{aeCount},currFeat);
end
end