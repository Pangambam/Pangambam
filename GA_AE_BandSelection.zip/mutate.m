%%
%MUTATION of a Child
function Gen = mutate(Gen)
for popCount = 1:size(Gen,1)
    currChild = Gen(popCount,:);
    muProbab = rand(1,size(currChild,2));
    MutgeneIDX = muProbab<0.03; %MUTATION PROBABILITY 3%
    currChild(MutgeneIDX) = currChild(MutgeneIDX);
    Gen(popCount,:) = currChild;
end
end